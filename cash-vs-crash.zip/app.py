import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

st.set_page_config(page_title="Cash vs Crash", layout="centered")

st.title("🚗 Cash vs Crash")
st.markdown("**Analisis hubungan antara harga mobil dan tingkat keamanannya di pasar Indonesia.**")

# Load dataset
try:
    df = pd.read_csv("data/cars_data.csv")
except FileNotFoundError:
    st.error("❌ File 'data/cars_data.csv' tidak ditemukan. Upload file di folder 'data/'.")
    st.stop()

# Tampilkan data
st.subheader("📄 Data Mobil")
st.dataframe(df)

# Statistik deskriptif
st.subheader("📊 Statistik Deskriptif")
st.write(df.describe())

# Visualisasi harga vs safety
st.subheader("📈 Scatter Plot: Harga vs Rating Keamanan")
fig, ax = plt.subplots(figsize=(10,6))
sns.scatterplot(data=df, x='Price', y='SafetyRating', hue='Brand', ax=ax)
ax.set_title("Cash vs Crash: Harga vs Keamanan Mobil")
ax.set_xlabel("Harga Mobil (juta IDR)")
ax.set_ylabel("Rating Keamanan (1–5)")
st.pyplot(fig)
